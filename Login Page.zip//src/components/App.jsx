import React from "react";
import Login from "./Login";

var isLoogedIn = true;

// function renderConditionally() {
//   if (isLoogedIn === true) {
//     return <h1>Hello</h1>;
//   } else {
//     return <Login />;
//   }
// }

function App() {
  return (
    <div className="container">
      {isLoogedIn ? <h1>Hello! You Have Succesfully Looged In</h1> : <Login />}
    </div>
  );
}

export default App;
